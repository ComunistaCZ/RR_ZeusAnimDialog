class CfgPatches {
    class RR_ZeusAnimDialog {
        units[] = {"RR_Module_PlayAnimation"};
        weapons[] = {};
        requiredAddons[] = {"A3_Modules_F"};
    };
};

class CfgFunctions {
    class rr_zeus_anim {
        class functions {
            file = "\RR_ZeusAnimDialog\functions";
            class initFunctions { postInit = 1; }; // PŘIDÁNO - inicializace při startu mise
            class playAnimation {};
            class doAnimation {};
            class fillCombo {};
            class executeAnim {};
        };
    };
};

class CfgFactionClasses {
    class NO_CATEGORY;
    class RR_Modules: NO_CATEGORY {
        displayName = "[44.RR] Zeus";
        priority = 2;
        side = 7;
    };
};

class CfgVehicles {
    class Logic;
    class Module_F: Logic {
        class ModuleDescription {
            class AnyBrain;
        };
    };

    class RR_Module_PlayAnimation: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "$STR_PLAY_ANIM_MODUL";
        icon = "\A3\ui_f\data\GUI\cfg\CommunicationMenu\transport_ca.paa";
        category = "RR_Modules";
        function = "rr_zeus_anim_fnc_playAnimation";
        functionPriority = 1;
        isGlobal = 1; // NASTAVENO NA 1 pro dedikovaný server
        isTriggerActivated = 0;
        isDisposable = 1;
        curatorInfoType = "";
        class ModuleDescription: ModuleDescription {
            description = "Otevře dialog a spustí animaci na jednotce.";
        };
    };
};

#include "dialogs.hpp"